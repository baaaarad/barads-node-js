import { useState } from 'react'
import FirstComp from "../components/FirstComp"

function App() {
  return (
    <>
    <FirstComp />
    </>
  )
}
export default App