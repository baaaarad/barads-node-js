import React from "react";
const FirstComp = () => {
  const arr = [
    { name: "task1", priority: "1" },
    { name: "task2", priority: "2" },
    { name: "task3", priority: "3" },
    { name: "task4", priority: "4" },
    { name: "task5", priority: "5" },
  ];
  function deleteElement() {
    var element = document.getElementById("DeleteMsg");
    element.parentNode.removeChild(element);
}
function line(){
 document.getElementById("LineOne").style.textDecoration="line-through";
 document.getElementById("LineOne").style.color="blue";
}


  return (
 
      <div
        className="card mx-auto bg-input mt-3 "
        style={{
          display:"flex",
          textAlign: "center",
          justifyContent: "center",
          alignItems: "center",
          width: "50%",
        }}
      >
        <h1>todo</h1>
        <input  type="text"  className="mb-3 py-2 w-75 rounded-2"  placeholder="Name"/>
        <input type="text" className=" w-75 py-2 rounded-2" placeholder="Priority"/>
        <textarea name="message" cols="10" rows="10" className="m-2 w-75 rounded-2" placeholder="type"></textarea>
        <button className=" mt-3 rounded-5 w-50 p-4 sub-hover">Submit</button>
        <button onClick={deleteElement} className=" mt-3 rounded-5 w-50 p-4 sub-hover1">Delete</button>
        <h2 id="DeleteMsg">click the botton above to delete this text</h2>
        <button onClick={line} className=" mt-3 rounded-3 w-50 py-2 sub-hover1">Line the text</button>
         <p id="LineOne" style={{fontSize:"30px", fontWeight:"bold"}}>click the botton above fot he text to be lined</p>
       
       
        {arr.map((element) => (
          <div>
            {element.name} {element.priority}
          </div>
        ))}
      </div>   
    
  );
};
export default FirstComp;
